Ejemplo basado en:

https://gist.github.com/optikalefx/4504947
